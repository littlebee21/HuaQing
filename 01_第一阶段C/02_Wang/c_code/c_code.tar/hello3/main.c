void print_helloworld();

int main()
{
	print_helloworld();
	return 0;
}
