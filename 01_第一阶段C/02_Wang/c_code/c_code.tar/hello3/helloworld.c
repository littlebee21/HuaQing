void print_hello();
void print_world();

void print_helloworld()
{
	print_hello();
	print_world();
}

