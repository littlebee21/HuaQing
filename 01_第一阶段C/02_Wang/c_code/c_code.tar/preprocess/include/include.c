#include "aaaaaa.h"
#include "bbb.h"

int main(int argc,char *argv[])
{
#if 0
	printf("Hello\n");
#else
	printf("Bybye\n");
#endif

#if 0
	asjkdfas
		asjdfjashdfj
		jhasgdfha
#endif
	return 0;
}
