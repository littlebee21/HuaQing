#include <stdio.h>

int f1();
int main(int argc,char *argv[])
{
	f1();

	return 0;
}
