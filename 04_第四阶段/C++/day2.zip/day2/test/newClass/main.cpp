#include <iostream>
using namespace std;

class Point{
private:
    double m_dPosx = 100.3;
    double m_dPosy = 95.26;
public:
    double getXPosValue();
    double getYPosValue();
    void setXPosValue(double);
    void setYPosValue(double);
};

void Point::setXPosValue(double x){
    m_dPosx = x;
}

void Point::setYPosValue(double y){
    m_dPosy = y;
}

double Point::getXPosValue(){
    return m_dPosx;
}

double Point::getYPosValue(){
    return m_dPosy;
}

int main()
{
    Point p;
    cout << "x's pos = " << p.getXPosValue() << endl;
    cout << "y's pos = " << p.getYPosValue() << endl;
    p.setXPosValue(123.12);
    p.setYPosValue(213.21);
    cout << "x's pos = " << p.getXPosValue() << endl;
    cout << "y's pos = " << p.getYPosValue() << endl;
    return 0;
}
