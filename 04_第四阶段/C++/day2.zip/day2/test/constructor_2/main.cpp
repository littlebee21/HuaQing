#include <iostream>

using namespace std;

class A{
public:
    A();
    int getXvalue()const{
        return x;
    }
    int getYvalue()const{
        return y;
    }
    int getZvalue()const{
        return z;
    }
    int getX2value()const{
        return x2;
    }
private:
    int x;
    int y = 200;
    int z;
    const int x1 = 1000;   // �������
    const int x2;
    int &rx;
};

A::A(): z(300), x2(2000), rx(x){
    x = 100;
}

int main()
{
    A a;
    cout << a.getXvalue() << endl;
    cout << a.getYvalue() << endl;
    cout << a.getZvalue() << endl;
    cout << a.getX2value() << endl;
    return 0;
}
