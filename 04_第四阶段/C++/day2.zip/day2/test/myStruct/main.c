#include <stdio.h>

int my_Add(int, int);
int my_Sub(int, int);

struct CTest{
    int (*Add)(int, int);
    int (*Sub)(int, int);
};

int my_Add(int x, int y){
    return x + y;
}

int my_Sub(int x, int y){
    return x - y;
}

int main()
{
    struct CTest test;
    test.Add = my_Add;
    test.Sub = my_Sub;
    printf("value = %d\n", test.Add(3, 5));
    printf("value = %d\n", test.Sub(3, 5));

    return 0;
}
