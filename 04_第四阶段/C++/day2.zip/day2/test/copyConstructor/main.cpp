#include <iostream>
#include <cstring>
using namespace std;

class Student{
public:
    // 默认拷贝构造函数(不写,默认会生成的函数)
    // 默认构造函数不带参数
    Student(){      // 构造函数，用来初始化数据成员，当创建对象时会调用构造函数
        m_strName = new char(20);
        cout << "This is Student's constructor" << endl;
    }
    Student(const Student& s){      // 自定义拷贝构造函数
        m_strName = new char(20);
        memcpy(m_strName, s.m_strName, strlen(s.m_strName));
        cout << "This is Student's copyConstructor" << endl;
    }
    ~Student(){     // 析构函数，用来释放资源，当释放资源的时候会调用析构函数(典型的delete时会调用)
        cout << "This is Student's destructor" << endl;
        delete m_strName;
        m_strName = nullptr;
    }
private:
    // int  m_nNum;         // 学生人数
    char *m_strName;        // 学生姓名
};

int main(){
    Student s1;
    Student s2 = s1;

    return 0;
}
