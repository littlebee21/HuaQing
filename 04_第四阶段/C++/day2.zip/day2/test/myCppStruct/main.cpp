#include <iostream>

using namespace std;

struct CppTest{
//    int a;
//    void func();
};

int main()
{
    cout << sizeof (CppTest) << endl;
    return 0;
}
