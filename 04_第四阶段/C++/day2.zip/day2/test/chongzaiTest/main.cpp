#include <iostream>

using namespace std;

void func(){
    cout << "This is func without paramaters" << endl;
}

void func(int x){
    x = 100;
    cout << "This is func with paramaters" << endl;
}

int main()
{
    func();
    func(1000);
    return 0;
}
