//#include <iostream>
//// #include <stdio.h>
//#include <cstdio>
//#include <cmath>
//#include <cstdlib>
//// C���ͷ�ļ���C++���Ƽ�ȥ��.h,��֮ǰ��c

////using namespace std;

//namespace xiaoLi {
//    bool b = false;
//}

//namespace xiaoHan {
//    int b = 100;
//}

//using namespace xiaoLi;
//int main()
//{
//    // cout << "xiaoHan'b = " << xiaoHan::b << endl;
//    // cout << "xiaoLi'b = " << xiaoLi::b << endl;
//    std::cout << b << std::endl;
//    return 0;
//}

#include <iostream>

//using namespace std;
int main()
{
  int x;
  std::cin >> x;
  std::cout << "123 is output!  " << x << std::endl;
  return 0;
}
