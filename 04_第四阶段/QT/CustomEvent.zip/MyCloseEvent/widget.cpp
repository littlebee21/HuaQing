#include "widget.h"
#include "ui_widget.h"
#include <QMessageBox>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
}

void Widget::closeEvent(QCloseEvent *event){
    QMessageBox msgBox;
    msgBox.setText("是否关闭窗口?");
    int ret = msgBox.warning(this, "警告", "是否关闭窗口?",
                   QMessageBox::Save | QMessageBox::Cancel,
                   QMessageBox::Save);
    switch (ret) {
    case QMessageBox::Save:
        event->accept();    // 接收关闭请求,将请求发送给父窗体
        break;
    case QMessageBox::Cancel:
        event->ignore();    // 忽略请求,将忽略请求发送给父窗体
        break;
    default:
        break;
    }
}

Widget::~Widget(){
    delete ui;
}
