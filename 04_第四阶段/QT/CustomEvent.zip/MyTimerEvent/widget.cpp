#include "widget.h"
#include "ui_widget.h"
#include <QDebug>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget){
    ui->setupUi(this);

    // timerEvent
    using namespace std::chrono;
    startTimer(1s); // C++ 14 support
    // 关掉timerEvent
    // killTimer(event->timerId());
    // QTimer
    m_pTimer = new QTimer(this);
    connect(m_pTimer, &QTimer::timeout, this, &Widget::slotShowPrintMsg);
    m_pTimer->start(1000);
    // 关闭QTimer定时器:
    // m_pTimer->stop();
}

void Widget::timerEvent(QTimerEvent *event){
    qDebug() << "Timer ID:" << event->timerId();
}

void Widget::slotShowPrintMsg(){
    qDebug() << "hello";
}

Widget::~Widget(){
    delete ui;
    delete m_pTimer;
    m_pTimer = nullptr;
}



