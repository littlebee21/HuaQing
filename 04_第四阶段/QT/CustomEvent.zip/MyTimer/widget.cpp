#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    m_pTimer = new QTimer(this);
    connect(ui->pushButton, &QAbstractButton::clicked,
            this, &Widget::slotCloseWidget);
    connect(m_pTimer, &QTimer::timeout, this, &QWidget::close);
}

void Widget::slotCloseWidget(){
    m_pTimer->start(8000);
}

Widget::~Widget(){
    delete ui;
    delete m_pTimer;    // 可以不写
    m_pTimer = nullptr;
}
