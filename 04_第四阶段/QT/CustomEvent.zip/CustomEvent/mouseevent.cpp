#include "mouseevent.h"

MouseEvent::MouseEvent(QWidget *parent)
    : QWidget(parent)
{
    m_bFlag = false;
}

void MouseEvent::mousePressEvent(QMouseEvent *event){
    // 记录鼠标点击的位置
    if(event->button() == Qt::LeftButton){
        m_point = event->globalPos() - pos();
        m_bFlag = true;
    }
}

void MouseEvent::mouseMoveEvent(QMouseEvent *event){
    if(m_bFlag){
        move(event->globalPos() - m_point);
    }
}

void MouseEvent::mouseReleaseEvent(QMouseEvent *event){
    Q_UNUSED(event) // 去掉不用参数的宏
    m_bFlag = false;
}

MouseEvent::~MouseEvent(){

}
