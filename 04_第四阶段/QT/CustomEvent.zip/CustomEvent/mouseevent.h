#ifndef MOUSEEVENT_H
#define MOUSEEVENT_H
#include <QWidget>
#include <QMouseEvent>
#include <QPoint>

class MouseEvent : public QWidget{
    Q_OBJECT

public:
    MouseEvent(QWidget *parent = nullptr);
    ~MouseEvent();

protected:
    virtual void mousePressEvent(QMouseEvent *event) override;
    virtual void mouseMoveEvent(QMouseEvent *event) override;
    virtual void mouseReleaseEvent(QMouseEvent *event) override;

private:
    QPoint m_point; // 坐标
    bool m_bFlag;   // 鼠标点击的标志
};
#endif // MOUSEEVENT_H
