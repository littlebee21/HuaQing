#include "widget.h"
#include "ui_widget.h"
#include <QDebug>

Widget::Widget(MouseEvent *parent)
    : MouseEvent(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    // 去边框
    setWindowFlag(Qt::FramelessWindowHint);
}

Widget::~Widget(){
    delete ui;
}


