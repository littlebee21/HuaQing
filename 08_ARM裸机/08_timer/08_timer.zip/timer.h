#ifndef __TIMER_H__
#define __TIMER_H__
#include "exynos_4412.h"

void timer_init(void);
void timer_gic_init(void);


#endif // __TIMER_H__
