#ifndef __KEY_H__
#define __KEY_H__
#include "exynos_4412.h"

void key_gpio_init(void);

void key_gic_init(void);


#endif // __KEY_H__
